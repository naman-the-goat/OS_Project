#include <iostream>
#include <list>
#include <functional>
#include <stdlib.h>
#include <cstring>
#include <pthread.h>
#include <chrono>

// 1D arguments
struct Args1D {
    int start;
    int end;
    std::function<void(int)> func; // Lambda function
};

// 2D arguments
struct Args2D {
    int startR, endR; // Outer loop
    int startC, endC; // Inner loop
    std::function<void(int, int)> func;
};

// 1D worker
void* worker1D(void* ptr) {
    // Cast args
    Args1D* args = static_cast<Args1D*>(ptr);
    
    // Run loop
    for (int i = args->start; i < args->end; i++) {
        args->func(i);
    }
    return NULL;
}

// 2D worker
void* worker2D(void* ptr) {
    Args2D* args = static_cast<Args2D*>(ptr);
    
    for (int i = args->startR; i < args->endR; i++) {
        for (int j = args->startC; j < args->endC; j++) {
            args->func(i, j);
        }
    }
    return NULL;
}

// 1D parallel_for
void parallel_for(int start, int end, std::function<void(int)> &&lambda, int nThreads) {
    // Start timer
    auto t1 = std::chrono::high_resolution_clock::now();

    // Thread arrays
    pthread_t tHandles[nThreads];
    Args1D tArgs[nThreads];

    // Chunk size
    int size = end - start;
    int chunk = size / nThreads;

    for (int i = 0; i < nThreads; i++) {
        // Thread bounds
        tArgs[i].start = start + (i * chunk);
        
        // Last chunk
        if (i == nThreads - 1) {
            tArgs[i].end = end;
        } else {
            tArgs[i].end = start + ((i + 1) * chunk);
        }
        
        tArgs[i].func = lambda;

        // Create thread
        if (pthread_create(&tHandles[i], NULL, worker1D, (void*)&tArgs[i]) != 0) {
            std::cerr << "Error creating thread" << std::endl;
            exit(1);
        }
    }

    // Join threads
    for (int i = 0; i < nThreads; i++) {
        pthread_join(tHandles[i], NULL);
    }

    // End timer
    auto t2 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> time_span = t2 - t1;
    std::cout << "Parallel execution time: " << time_span.count() << " ms\n";
}

// 2D parallel_for
void parallel_for(int startR, int endR, int startC, int endC, std::function<void(int, int)> &&lambda, int nThreads) {
    auto t1 = std::chrono::high_resolution_clock::now();

    pthread_t tHandles[nThreads];
    Args2D tArgs[nThreads];

    // Parallelize outer
    int rows = endR - startR;
    int chunk = rows / nThreads;

    for (int i = 0; i < nThreads; i++) {
        tArgs[i].startR = startR + (i * chunk);
        
        if (i == nThreads - 1) {
            tArgs[i].endR = endR;
        } else {
            tArgs[i].endR = startR + ((i + 1) * chunk);
        }

        // Inner range
        tArgs[i].startC = startC;
        tArgs[i].endC = endC;
        tArgs[i].func = lambda;

        if (pthread_create(&tHandles[i], NULL, worker2D, (void*)&tArgs[i]) != 0) {
            std::cerr << "Error creating thread" << std::endl;
            exit(1);
        }
    }

    for (int i = 0; i < nThreads; i++) {
        pthread_join(tHandles[i], NULL);
    }

    auto t2 = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> time_span = t2 - t1;
    std::cout << "Parallel execution time: " << time_span.count() << " ms\n";
}

// Provided code
int user_main(int argc, char **argv);

void demonstration(std::function<void()> && lambda) {
  lambda();
}

int main(int argc, char **argv) {
  int x=5,y=1;
  auto lambda1 = [x, &y](void) {
    y = 5;
    std::cout<<"====== Welcome to Assignment-"<<y<<" of the CSE231(A) ======\n";
  };
  demonstration(lambda1);

  int rc = user_main(argc, argv);
 
  auto lambda2 = []() {
    std::cout<<"====== Hope you enjoyed CSE231(A) ======\n";
  };
  demonstration(lambda2);
  return rc;
}

#define main user_main