#include "loader.h"

int fd = -1;                      
void *loaded_segment = NULL;      
size_t loaded_size = 0;           

// Cleanup mapped memory and file descriptor
void loader_cleanup() {
    if (loaded_segment && loaded_segment != MAP_FAILED) {
        munmap(loaded_segment, loaded_size);  
        loaded_segment = NULL;
        loaded_size = 0;
    }
    if (fd >= 0) {
        close(fd);                 
        fd = -1;
    }
}

void load_and_run_elf(char **program_argv) {
    const char *elf_filename = program_argv[0];

    // Step 1: Open the ELF file
    // Open the ELF executable in read-only mode.
    fd = open(elf_filename, O_RDONLY);
    if (fd < 0) {
        perror("open");
        exit(1);
    }

    // Step 2: Read ELF header
    Elf32_Ehdr elf_header;
    if (read(fd, &elf_header, sizeof(elf_header)) != sizeof(elf_header)) {
        perror("read ELF header");
        exit(1);
    }

    // Step 3: Validate ELF magic number
    // The first 4 bytes of an ELF file must be: 0x7F, 'E', 'L', 'F'.
    if (!(elf_header.e_ident[EI_MAG0] == ELFMAG0 &&
          elf_header.e_ident[EI_MAG1] == ELFMAG1 &&
          elf_header.e_ident[EI_MAG2] == ELFMAG2 &&
          elf_header.e_ident[EI_MAG3] == ELFMAG3)) {
        fprintf(stderr, "Error: Not a valid ELF file: %s\n", elf_filename);
        exit(1);
    }

    // Save the program entry point address from the ELF header.
    Elf32_Addr entry_point_addr = elf_header.e_entry;

    // Step 4: Iterate over Program Headers
    // We loop through them to find the loadable segment (PT_LOAD) that contains the entry point.
    for (int i = 0; i < elf_header.e_phnum; i++) {
        Elf32_Phdr prog_header;

        // Seek to the location of the i-th program header in the file.
        if (lseek(fd, elf_header.e_phoff + i * elf_header.e_phentsize, SEEK_SET) == -1) {
            perror("lseek program header");
            exit(1);
        }

        // Read the program header from the ELF file.
        if (read(fd, &prog_header, sizeof(prog_header)) != sizeof(prog_header)) {
            perror("read program header");
            exit(1);
        }

        // Step 5: Identify target segment
        // We are only interested in PT_LOAD segments (loadable into memory). Additionally, we check if the program's entry point lies inside this segment's virtual address range.
        if (prog_header.p_type == PT_LOAD &&
            entry_point_addr >= prog_header.p_vaddr &&
            entry_point_addr < prog_header.p_vaddr + prog_header.p_memsz) {

            // Step 6: Map segment into memory
            // Use mmap() to map the segment into our process's memory space.
            // PROT_READ | PROT_WRITE | PROT_EXEC: allows read/write/execute.
            // MAP_PRIVATE ensures we get a private copy-on-write mapping.
            loaded_size = prog_header.p_memsz;
            loaded_segment = mmap(
                NULL,                 
                loaded_size,           
                PROT_READ | PROT_WRITE | PROT_EXEC, 
                MAP_PRIVATE,                
                fd,                       
                prog_header.p_offset        
            );
            if (loaded_segment == MAP_FAILED) {
                perror("mmap");
                exit(1);
            }

            // Step 7: Calculate entry point address in memory
            // The runtime entry address is computed as: (mapped segment base) + (entry_point - segment virtual address).
            void *runtime_entry_addr = (char *)loaded_segment + 
                                       (entry_point_addr - prog_header.p_vaddr);

            // Step 8: Transfer control to ELF entry point
            // Cast the entry point to a function pointer and call it.
            typedef int (*entry_func_t)(void);
            entry_func_t entry_func = (entry_func_t)runtime_entry_addr;

            int exit_code = entry_func();
            printf("Program exited with code %d\n", exit_code);

            return;  
        }
    }

    // Step 9: No valid segment found
    // If no PT_LOAD segment containing the entry point was found, print an error and terminate.
    fprintf(stderr, "Error: Entry point not found in any PT_LOAD segment\n");
    exit(1);
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <elf-executable>\n", argv[0]);
        return 1;
    }

    load_and_run_elf(&argv[1]);

    loader_cleanup();
    return 0;
}