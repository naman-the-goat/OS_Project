#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>

#define MAX_CMD_LEN 1024
#define MAX_HISTORY 100

// structure to store history of commands
typedef struct {
    char cmd[MAX_CMD_LEN];
    pid_t proc_id;
    time_t start_t;
    double run_time;
} HistoryRec;

HistoryRec hist[MAX_HISTORY];
int hist_count=0;

// --- History Functions ---

// add entry into history
void addHistory(const char* inp_cmd,pid_t proc_id,time_t start_t,double run_time){
    if(hist_count<MAX_HISTORY){
        strncpy(hist[hist_count].cmd,inp_cmd,MAX_CMD_LEN);
        hist[hist_count].proc_id=proc_id;
        hist[hist_count].start_t=start_t;
        hist[hist_count].run_time=run_time;
        hist_count++;
    }
}

// print command history
void showHist(){
    printf("---- Command History ----\n");
    for(int i=0;i<hist_count;i++){
        char t_str[20];
        strftime(t_str,sizeof(t_str),"%H:%M:%S",localtime(&hist[i].start_t));
        printf("%d) PID=%d | CMD=%s | Start=%s | Duration=%.2fs\n",
               i+1,
               hist[i].proc_id,
               hist[i].cmd,
               t_str,
               hist[i].run_time);
    }
}

// --- Utility Functions ---

// read a line of input from stdin
char* readLine(){
    char* line=NULL;
    size_t bsize=0;

    if(getline(&line,&bsize,stdin)==-1){
        if(feof(stdin))exit(0); // Ctrl+D exits
        perror("getline failed");
        exit(1);
    }

    line[strcspn(line,"\n")]='\0'; // remove newline
    return line;
}

// split line into commands separated by '|'
char** splitCmds(char* line,int* cmd_count){
    int size=1024;
    char** cmds=malloc(size*sizeof(char*));
    *cmd_count=0;

    char* tok=strtok(line,"|");
    while(tok){
        cmds[*cmd_count]=tok;
        (*cmd_count)++;
        tok=strtok(NULL,"|");
    }
    cmds[*cmd_count]=NULL;
    return cmds;
}

// split command into arguments
char** splitArgs(char* cmd_str){
    int size=256,pos=0;
    char** args=malloc(size*sizeof(char*));

    char* tok=strtok(cmd_str," \t");
    while(tok){
        args[pos++]=tok;
        tok=strtok(NULL," \t");
    }
    args[pos]=NULL;
    return args;
}

// --- Execution Functions ---

// run a single command
void runSingleCmd(char* cmd_str){
    char** args=splitArgs(cmd_str);
    if(args[0]==NULL){
        free(args);
        return;
    }

    time_t start_t=time(NULL);

    pid_t proc_id=fork();
    if(proc_id<0){
        perror("fork failed");
    } else if(proc_id==0){
        execvp(args[0],args); // child process executes
        perror("execvp failed");
        exit(EXIT_FAILURE);
    } else {
        waitpid(proc_id,NULL,0); // parent waits
        double run_time=difftime(time(NULL),start_t);
        addHistory(cmd_str,proc_id,start_t,run_time);
    }

    free(args);
}

// run multiple commands connected with pipes
void runPipe(char** cmds,int cmd_count){
    if(cmd_count<=0)return;
    if(cmd_count==1){
        runSingleCmd(cmds[0]);
        return;
    }

    int pfd[2];
    int in_fd=0; // input fd for next command

    for(int i=0;i<cmd_count;i++){
        if(i<cmd_count-1){
            if(pipe(pfd)<0){
                perror("pipe failed");
                exit(EXIT_FAILURE);
            }
        }

        time_t start_t=time(NULL);
        pid_t proc_id=fork();

        if(proc_id<0){
            perror("fork failed");
            exit(EXIT_FAILURE);
        }

        if(proc_id==0){
            // child process redirections
            if(in_fd!=0){
                dup2(in_fd,STDIN_FILENO);
                close(in_fd);
            }
            if(i<cmd_count-1){
                dup2(pfd[1],STDOUT_FILENO);
                close(pfd[0]);
                close(pfd[1]);
            }

            char** args=splitArgs(cmds[i]);
            execvp(args[0],args);
            perror("execvp failed");
            free(args);
            exit(EXIT_FAILURE);
        } else {
            // parent waits and records history
            waitpid(proc_id,NULL,0);
            double run_time=difftime(time(NULL),start_t);
            addHistory(cmds[i],proc_id,start_t,run_time);

            if(in_fd!=0)close(in_fd);
            if(i<cmd_count-1){
                close(pfd[1]);
                in_fd=pfd[0];
            }
        }
    }
}

// --- Signal Handler ---

// handle Ctrl+C
void sigHandler(int sig){
    printf("\nSimpleShell terminated. Execution history:\n");
    showHist();
    exit(0);
}

// --- Main Function ---

int main(){
    signal(SIGINT,sigHandler);

    char* line;
    char** cmds;
    int cmd_count;
    int status=1;

    do {
        printf("simple-shell> ");
        fflush(stdout);

        line=readLine();
        if(strlen(line)==0){
            free(line);
            continue;
        }

        char line_cpy[MAX_CMD_LEN];
        strncpy(line_cpy,line,MAX_CMD_LEN);

        char* f_word=strtok(line," \t\r\n\a");
        if(f_word!=NULL){
            if(strcmp(f_word,"exit")==0){
                status=0;
            } else if(strcmp(f_word,"history")==0){
                showHist();
            } else {
                strcpy(line,line_cpy);
                cmds=splitCmds(line,&cmd_count);
                if(cmd_count>0){
                    runPipe(cmds,cmd_count);
                }
                free(cmds);
            }
        }

        free(line);

    } while(status);

    return 0;
}
