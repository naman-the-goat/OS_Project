#include "loader.h"
#include <signal.h> 
#include <stdint.h> 
#include<errno.h>  
#include <string.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <sys/mman.h> 
#include <math.h>   

#define MAX_SEGMENTS 10
#define PAGE_SIZE 4096

int file_descriptor = -1; // ELF file handle

static Elf32_Phdr program_segments[MAX_SEGMENTS];
static int seg_counter = 0;

static int fault_counter = 0; // Page fault tracking
static int alloc_counter = 0; // Allocation tracking
static size_t frag_bytes = 0; // Fragmentation tracking

#define TOTAL_VPNS (1 << 20)
static uint8_t *bitmap = NULL; // Page presence bitmap

static inline int is_page_mapped(uint32_t vpn) {
    return bitmap[vpn / 8] & (1 << (vpn % 8));
}

static inline void map_page(uint32_t vpn) {
    bitmap[vpn / 8] |= (1 << (vpn % 8));
}

static inline void unmap_page(uint32_t vpn) {
    bitmap[vpn / 8] &= ~(1 << (vpn % 8));
}

static void page_fault_handler(int sig, siginfo_t *si, void *unused) {
    fault_counter++;
    
    void *addr = si->si_addr;

    Elf32_Phdr *seg = NULL; // Find segment
    for (int i = 0; i < seg_counter; i++) {
        void *start = (void *)(uintptr_t)program_segments[i].p_vaddr;
        void *end = start + program_segments[i].p_memsz;
        if (addr >= start && addr < end) {
            seg = &program_segments[i];
            break;
        }
    }

    if (seg == NULL) {
        fprintf(stderr, "[SimpleSmartLoader] Error: Invalid memory access (real Segmentation Fault) at %p.\n", addr);
        exit(1);
    }

    uintptr_t page_addr = (uintptr_t)addr & ~(PAGE_SIZE - 1); // Align address
    uint32_t vpn = page_addr / PAGE_SIZE;

    if (is_page_mapped(vpn)) {
        return; // Already mapped
    }

    alloc_counter++;
    void *mem = mmap((void *)page_addr, PAGE_SIZE, // Allocate page
                            PROT_READ | PROT_WRITE | PROT_EXEC,
                            MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED,
                            -1, 0);

    if (mem == MAP_FAILED) {
        perror("mmap in handler");
        exit(1);
    }

    map_page(vpn); // Mark present

    uintptr_t file_off = seg->p_offset;
    uintptr_t mem_off = seg->p_vaddr;
    size_t file_len = seg->p_filesz;
    uintptr_t page_off = page_addr - mem_off;

    if (page_off < file_len) { // Load from file
        uintptr_t offset = file_off + page_off;
        size_t read_len = file_len - page_off;
        if (read_len > PAGE_SIZE) {
            read_len = PAGE_SIZE;
        }

        if (lseek(file_descriptor, offset, SEEK_SET) == -1) {
            perror("lseek in handler");
            exit(1);
        }
        if (read(file_descriptor, (void *)page_addr, read_len) < 0) {
            perror("read in handler");
            exit(1);
        }
    }

    uintptr_t seg_end = seg->p_vaddr + seg->p_memsz;
    if (page_addr + PAGE_SIZE >= seg_end) { // Calculate fragmentation
        size_t used = seg_end % PAGE_SIZE;
        if (used != 0) {
            frag_bytes += (PAGE_SIZE - used);
        }
    }
}



void loader_cleanup() {
    if (bitmap) { // Unmap pages
        for (uint32_t vpn = 0; vpn < TOTAL_VPNS; vpn++) {
            if (is_page_mapped(vpn)) {
                munmap((void *)(uintptr_t)(vpn * PAGE_SIZE), PAGE_SIZE);
                unmap_page(vpn); 
            }
        }
        free(bitmap);
        bitmap = NULL;
    }

    if (file_descriptor >= 0) {
        close(file_descriptor);
        file_descriptor = -1;
    }
}


void load_and_run_elf(char **program_argv) {
    const char *filename = program_argv[0];

    file_descriptor = open(filename, O_RDONLY);
    if (file_descriptor < 0) {
        perror("open");
        exit(1);
    }

    Elf32_Ehdr hdr;
    if (read(file_descriptor, &hdr, sizeof(hdr)) != sizeof(hdr)) {
        perror("read ELF header");
        loader_cleanup();
        exit(1);
    }

    if (!(hdr.e_ident[EI_MAG0] == ELFMAG0 && // Validate ELF
          hdr.e_ident[EI_MAG1] == ELFMAG1 &&
          hdr.e_ident[EI_MAG2] == ELFMAG2 &&
          hdr.e_ident[EI_MAG3] == ELFMAG3)) {
        fprintf(stderr, "Error: Not a valid ELF file: %s\n", filename);
        loader_cleanup();
        exit(1);
    }

    Elf32_Addr entry = hdr.e_entry;

    for (int i = 0; i < hdr.e_phnum; i++) { // Load segments
        Elf32_Phdr phdr;

        if (lseek(file_descriptor, hdr.e_phoff + i * hdr.e_phentsize, SEEK_SET) == -1) {
            perror("lseek program header");
            loader_cleanup();
            exit(1);
        }

        if (read(file_descriptor, &phdr, sizeof(phdr)) != sizeof(phdr)) {
            perror("read program header");
            loader_cleanup();
            exit(1);
        }

        if (phdr.p_type == PT_LOAD) {
            if (seg_counter < MAX_SEGMENTS) {
                program_segments[seg_counter++] = phdr;
            } else {
                fprintf(stderr, "Error: Too many PT_LOAD segments.\n");
                loader_cleanup();
                exit(1);
            }
        }
    }

    if (seg_counter == 0) {
        fprintf(stderr, "Error: No PT_LOAD segments found.\n");
        loader_cleanup();
        exit(1);
    }

    size_t bitmap_size = (TOTAL_VPNS / 8) + 1;
    bitmap = (uint8_t *)calloc(bitmap_size, 1);
    if (bitmap == NULL) {
        perror("calloc for page_map");
        loader_cleanup();
        exit(1);
    }

    struct sigaction sa; // Register handler
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = page_fault_handler;
    sa.sa_flags = SA_SIGINFO | SA_RESTART; 
    if (sigaction(SIGSEGV, &sa, NULL) == -1) {
        perror("sigaction");
        loader_cleanup();
        exit(1);
    }

    typedef int (*entry_func_t)(void);
    entry_func_t func = (entry_func_t)(uintptr_t)entry;

    int code = func(); // Execute program

    printf("\n--- SimpleSmartLoader Statistics ---\n");
    printf("Program exited with code %d\n", code);
    printf("Total Page Faults:      %d\n", fault_counter);
    printf("Total Page Allocations: %d\n", alloc_counter);
    printf("Total Internal Fragmentation: %.2f KB\n", (double)frag_bytes / 1024.0);
}


int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <elf-executable>\n", argv[0]);
        return 1;
    }

    load_and_run_elf(&argv[1]);

    loader_cleanup();
    return 0;
}