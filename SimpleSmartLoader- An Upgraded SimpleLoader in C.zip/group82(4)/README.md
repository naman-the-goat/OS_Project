# OS Assignment 1 - ELF File Loader

## Team Members
- **Shaffil Saini** (2024517)
- **Naman Gupta** (2024368)

## Overview
This project implements a custom ELF (Executable and Linkable Format) file loader that can read, validate, and execute ELF files by mapping them into memory and jumping to their entry points.

## Approach

Our ELF loader follows these key steps:

1. **Open ELF file** → Read the file into memory
2. **Read & validate ELF header** → Check magic number (0x7F 'E' 'L' 'F')
3. **Find entry point address** → Extract from ELF header
4. **Iterate program headers** → Look for PT_LOAD segment containing the entry point
5. **Map segment into memory** → Use `mmap()` for memory mapping
6. **Compute runtime entry address** → Calculate actual address inside mapped memory
7. **Jump to entry point** → Cast to function pointer and execute
8. **Cleanup** → Free memory and close file descriptor

## Team Contributions

| Team Member | Responsibilities |
|-------------|------------------|
| **Naman Gupta** | Loader logic, memory mapping, parsing ELF file |
| **Shaffil Saini** | Error handling and documentation |

## Repository
🔒 **Private Repository**: [os_assignment](https://github.com/naman-the-goat/os_assignment)

## Key Code Snippets

### ELF Magic Number Validation
```c
if (!(elf_header.e_ident[EI_MAG0] == ELFMAG0 &&
         elf_header.e_ident[EI_MAG1] == ELFMAG1 &&
         elf_header.e_ident[EI_MAG2] == ELFMAG2 &&
         elf_header.e_ident[EI_MAG3] == ELFMAG3)) {
       fprintf(stderr, "Error: Not a valid ELF file: %s\n", elf_filename);
       exit(1);
   }
```

**Explanation**: This code snippet performs validation to ensure the file being loaded is a proper ELF file. Every ELF file begins with a fixed four-byte signature (magic number): `0x7F`, followed by the characters 'E', 'L', and 'F'. These values are stored in the `e_ident` field of the ELF header.

### Memory Cleanup
```c
if (loaded_segment && loaded_segment != MAP_FAILED) {
       munmap(loaded_segment, loaded_size); 
       loaded_segment = NULL;
       loaded_size = 0;
   }
```

**Explanation**: This code safely cleans up memory that was mapped with `mmap()`. It first checks if the `loaded_segment` pointer is valid and not equal to `MAP_FAILED` (which indicates a failed mapping). If the memory was successfully mapped, it calls `munmap()` to release that region back to the system. `munmap()` is similar to `free()` for dynamically allocated memory.

## Technical Details

### ELF File Structure
- **ELF Header**: Contains metadata about the file format and entry point
- **Program Headers**: Describe segments to be loaded into memory
- **PT_LOAD Segments**: Loadable segments that contain executable code or data

### Memory Management
- Uses `mmap()` for mapping file contents into virtual memory
- Proper cleanup with `munmap()` to prevent memory leaks
- Handles mapping failures with appropriate error checking

## References

- **Course Material**: Lectures 2, 3, 4
- **Documentation**: 
  - [Linux ELF Manual Page](https://man7.org/linux/man-pages/man5/elf.5.html)
  - [ELF Tutorial - OSDev Wiki](https://wiki.osdev.org/ELF_Tutorial)

## AI-Generated Content Notice

Some code snippets in this project were generated with AI assistance for educational purposes, particularly for validation logic and memory management patterns.

---

**Note**: This assignment demonstrates understanding of:
- ELF file format and structure
- Memory mapping and virtual memory concepts
- System calls (`mmap`, `munmap`)
- File I/O operations
- Error handling in systems programming
