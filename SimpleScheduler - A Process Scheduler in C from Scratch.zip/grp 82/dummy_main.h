#ifndef DUMMY_MAIN_H
#define DUMMY_MAIN_H

#include <stdio.h>
#include <signal.h>
#include <unistd.h>

/*
 * You can add any code here you want to support your Simple Scheduler implementation
 */

// Forward declare the user's main function, which will be renamed to dummy_main
int dummy_main(int argc, char **argv);

// This new main function will be the entry point for the user's program.
int main(int argc, char **argv) {
    // Immediately stop the process, waiting for a SIGCONT from the scheduler.
    raise(SIGSTOP);

    // Once continued, call the user's original main function.
    int ret = dummy_main(argc, argv);
    return ret;
}

// This macro renames the user's main function to dummy_main
#define main dummy_main

#endif // DUMMY_MAIN_H
