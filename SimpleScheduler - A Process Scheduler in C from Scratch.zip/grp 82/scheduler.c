#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <string.h>

// --- Constants ---
#define MAX_MANAGED_PROCESSES 100    // Max processes the scheduler can handle
#define JOBS_INPUT_FILE "jobs.txt"   // File to read new process IDs from
#define SCHEDULER_REPORT_FILE "report.dat" // File to write final stats to

// --- Global State and Data Structures ---

// Struct to store performance metrics for each process
typedef struct {
    pid_t pid;                      // Process ID
    int time_slices_executed;       // Count of time slices the process has run
    int time_slices_waited;         // Count of time slices spent in the ready queue
} ProcessStats;

ProcessStats process_statistics_table[MAX_MANAGED_PROCESSES]; // Holds stats for all managed processes
int total_managed_processes = 0;   // Current number of processes in the statistics table

pid_t ready_pid_queue[MAX_MANAGED_PROCESSES]; // A circular queue for PIDs ready to run
int queue_head = 0, queue_tail = -1, queue_size = 0;

pid_t active_processes_on_cpu[MAX_MANAGED_PROCESSES]; // PIDs of currently running processes
int active_process_count = 0;     // Number of processes currently running

int CPU_CORE_COUNT;               // Number of virtual CPUs to simulate
int TIME_SLICE_MS;                // Duration of a time slice in milliseconds
int is_timer_running = 0;         // Flag to check if the scheduler's timer is active
struct itimerval scheduler_timer; // Timer configuration for scheduler ticks

// --- Ready Queue Management ---

// Adds a process ID to the back of the ready queue
void enqueue_process(pid_t pid) {
    if (queue_size < MAX_MANAGED_PROCESSES) {
        if (queue_tail == MAX_MANAGED_PROCESSES - 1) queue_tail = -1; // Wrap around
        ready_pid_queue[++queue_tail] = pid;
        queue_size++;
    }
}

// Removes and returns a process ID from the front of the ready queue
pid_t dequeue_process() {
    if (queue_size > 0) {
        pid_t pid = ready_pid_queue[queue_head++];
        if (queue_head == MAX_MANAGED_PROCESSES) queue_head = 0; // Wrap around
        queue_size--;
        return pid;
    }
    return -1; // Queue is empty
}

// --- Process Statistics Management ---

// Finds the index of a process in the statistics table
int find_process_stats_index(pid_t pid) {
    for (int i = 0; i < total_managed_processes; i++) {
        if (process_statistics_table[i].pid == pid) return i;
    }
    return -1; // Not found
}

// Creates a new statistics entry for a process
void initialize_process_statistics(pid_t pid) {
    // Only add if it's not already tracked and there's space
    if (total_managed_processes < MAX_MANAGED_PROCESSES && find_process_stats_index(pid) == -1) {
        process_statistics_table[total_managed_processes].pid = pid;
        process_statistics_table[total_managed_processes].time_slices_executed = 0;
        process_statistics_table[total_managed_processes].time_slices_waited = 0;
        total_managed_processes++;
    }
}

// --- Core Scheduling Logic ---

// Checks if a process with a given PID is still running
int does_process_exist(pid_t pid) {
    return (kill(pid, 0) == 0); // kill with signal 0 checks existence without sending a signal
}

// Stops all currently running processes and moves them back to the ready queue
void stop_and_requeue_processes(pid_t* previously_running, int prev_count) {
    for (int i = 0; i < prev_count; i++) {
        pid_t pid = previously_running[i];
        if (does_process_exist(pid)) {
            kill(pid, SIGSTOP);    // Pause the process
            enqueue_process(pid); // Add it back to the ready queue
        }
    }
    active_process_count = 0;
}

// Dispatches new processes from the ready queue to run on the virtual CPUs
void dispatch_new_processes() {
    // Fill up the available CPU cores
    while (active_process_count < CPU_CORE_COUNT && queue_size > 0) {
        pid_t pid_to_run = dequeue_process();
        if (pid_to_run != -1) {
            active_processes_on_cpu[active_process_count++] = pid_to_run;
            kill(pid_to_run, SIGCONT); // Resume the process
        }
    }
}

// The main scheduler function, triggered by the timer signal (SIGALRM)
void scheduler_tick_handler(int sig) {
    (void)sig; // Unused parameter

    // 1. ACCOUNT FOR THE TIME SLICE THAT JUST ENDED
    // Update execution time for running processes
    for (int i = 0; i < active_process_count; i++) {
        int idx = find_process_stats_index(active_processes_on_cpu[i]);
        if (idx != -1) process_statistics_table[idx].time_slices_executed++;
    }
    // Update wait time for queued processes
    int current_q_idx = queue_head;
    for (int i = 0; i < queue_size; i++) {
        int idx = find_process_stats_index(ready_pid_queue[current_q_idx]);
        if (idx != -1) process_statistics_table[idx].time_slices_waited++;
        current_q_idx = (current_q_idx + 1) % MAX_MANAGED_PROCESSES;
    }

    // 2. PERFORM THE CONTEXT SWITCH
    pid_t previously_running[MAX_MANAGED_PROCESSES];
    int prev_running_count = active_process_count;
    memcpy(previously_running, active_processes_on_cpu, sizeof(pid_t) * active_process_count);

    stop_and_requeue_processes(previously_running, prev_running_count);
    dispatch_new_processes();

    // 3. HOUSEKEEPING: If no processes are left, stop the scheduler timer
    if (active_process_count == 0 && queue_size == 0) {
        struct itimerval stop_timer = {{0, 0}, {0, 0}};
        setitimer(ITIMER_REAL, &stop_timer, NULL);
        is_timer_running = 0;
    }
}

// --- Process Lifecycle and Termination ---

// Registers a new process with the scheduler and adds it to the ready queue
void register_new_process(pid_t new_pid) {
    initialize_process_statistics(new_pid);
    enqueue_process(new_pid);
    // If the scheduler was idle, start the timer and run the scheduler immediately
    if (!is_timer_running) {
        setitimer(ITIMER_REAL, &scheduler_timer, NULL);
        is_timer_running = 1;
        scheduler_tick_handler(0); // Manually trigger first schedule
    }
}

// Periodically checks the jobs file for new PIDs to schedule
void poll_for_new_jobs() {
    FILE* file = fopen(JOBS_INPUT_FILE, "r");
    if (!file) return;

    pid_t new_pid;
    // Read each PID from the file
    while (fscanf(file, "%d\n", &new_pid) == 1) {
        if (find_process_stats_index(new_pid) == -1) { // Check if we are already managing it
            register_new_process(new_pid);
        }
    }
    fclose(file);
    // Clear the file so jobs aren't added again
    file = fopen(JOBS_INPUT_FILE, "w");
    if (file) fclose(file);
}

// Signal handler for SIGTERM to clean up and exit gracefully
void cleanup_and_exit_handler(int sig) {
    (void)sig; // Unused parameter

    // Write the final statistics to the report file
    FILE* report_file = fopen(SCHEDULER_REPORT_FILE, "w");
    if (report_file) {
        for (int i = 0; i < total_managed_processes; i++) {
            fprintf(report_file, "PID: %d, ExecutedSlices: %d, WaitedSlices: %d\n",
                    process_statistics_table[i].pid,
                    process_statistics_table[i].time_slices_executed,
                    process_statistics_table[i].time_slices_waited);
        }
        fclose(report_file);
    }

    // Terminate all managed child processes
    for (int i = 0; i < total_managed_processes; i++) {
        if (does_process_exist(process_statistics_table[i].pid)) {
            kill(process_statistics_table[i].pid, SIGKILL);
        }
    }
    exit(0);
}

// --- Main Function ---
int main(int argc, char *argv[]) {
    // Validate command-line arguments
    if (argc != 3) {
        fprintf(stderr, "Usage: ./SimpleScheduler <NCPU> <TSLICE>\n");
        return 1;
    }
    CPU_CORE_COUNT = atoi(argv[1]);
    TIME_SLICE_MS = atoi(argv[2]);

    // Set up signal handlers
    signal(SIGTERM, cleanup_and_exit_handler); // For graceful shutdown
    signal(SIGALRM, scheduler_tick_handler);   // For scheduler ticks

    // Clear input and output files on startup
    FILE* file = fopen(JOBS_INPUT_FILE, "w");
    if(file) fclose(file);
    file = fopen(SCHEDULER_REPORT_FILE, "w");
    if(file) fclose(file);

    // Configure the interval timer for the scheduler
    scheduler_timer.it_value.tv_sec = TIME_SLICE_MS / 1000;
    scheduler_timer.it_value.tv_usec = (TIME_SLICE_MS % 1000) * 1000;
    scheduler_timer.it_interval = scheduler_timer.it_value;

    printf("Scheduler started. PID: %d, CPU Cores: %d, Time Slice: %dms\n", getpid(), CPU_CORE_COUNT, TIME_SLICE_MS);

    // Main loop: continuously check for new jobs
    while (1) {
        poll_for_new_jobs();
        usleep(100000); // Poll every 100ms
    }

    return 0;
}