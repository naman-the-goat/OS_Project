#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <libgen.h>

#define MAX_SIZE 1024
#define MAX_JOBS 100
#define JOBS_FILE "jobs.txt"
#define REPORT_FILE "report.dat"

// Job struct holds all information about a submitted process
typedef struct {
    char name[MAX_SIZE];
    pid_t pid;
    int has_completed;
    int time_sc_executed;
    int time_sc_waited;
} Job;

// Global state for the shell
Job job_list[MAX_JOBS];
int job_count = 0;
int tslice_val = 0;
pid_t scheduler_pid = -1;

// --- Function Prototypes ---
void cleanup_and_exit(int sig);

int is_job_managed(pid_t pid) {
    for (int i = 0; i < job_count; i++) {
        if (job_list[i].pid == pid && !job_list[i].has_completed) {
            return 1;
        }
    }
    return 0;
}

void handle_submit_command(char* args[]) {
    if (args[1] == NULL) {
        printf("Usage: submit <executable_path>\n");
        return;
    }
    pid_t pid = fork();
    if (pid == 0) {
        raise(SIGSTOP);
        execvp(args[1], &args[1]);
        perror("execvp failed");
        exit(1);
    } else if (pid > 0) {
        if (job_count < MAX_JOBS) {
            strcpy(job_list[job_count].name, args[1]);
            job_list[job_count].pid = pid;
            job_count++;
        }
        // Write the new PID to the jobs file
        FILE* f = fopen(JOBS_FILE, "a");
        if (f) {
            fprintf(f, "%d\n", pid);
            fclose(f);
        }
        printf("Job %d submitted.\n", pid);
    } else {
        perror("fork failed");
    }
}

void handle_kill_command(char* args[]) {
    if (args[1] == NULL) {
        printf("Usage: kill <PID>\n");
        return;
    }
    pid_t pid_to_kill = atoi(args[1]);
    if (!is_job_managed(pid_to_kill)) {
        printf("Error: No active job with PID %d.\n", pid_to_kill);
        return;
    }
    if (kill(pid_to_kill, SIGTERM) == 0) {
        printf("Termination signal sent to job %d.\n", pid_to_kill);
    } else {
        perror("kill failed");
    }
}

void shell_loop() {
    char input[MAX_SIZE];
    char* args[MAX_SIZE];
    while (1) {
        char cwd[MAX_SIZE];
        if (getcwd(cwd, sizeof(cwd)) != NULL) {
            printf("SimpleShell:%s$ ", basename(cwd));
        } else {
            printf("SimpleShell$ ");
        }
        fflush(stdout);
        if (fgets(input, sizeof(input), stdin) == NULL) break;
        input[strcspn(input, "\n")] = 0;
        if (strlen(input) == 0) continue;
        char input_copy[MAX_SIZE];
        strcpy(input_copy, input);
        int i = 0;
        char* token = strtok(input_copy, " ");
        while(token != NULL) { args[i++] = token; token = strtok(NULL, " "); }
        args[i] = NULL;
        if (args[0] == NULL) continue;
        if (strcmp(args[0], "exit") == 0) {
            break;
        } else if (strcmp(args[0], "submit") == 0) {
            handle_submit_command(args);
        } else if (strcmp(args[0], "kill") == 0) {
            handle_kill_command(args);
        } else {
            printf("Unknown command: %s (Available: submit, kill, exit)\n", args[0]);
        }
    }
    cleanup_and_exit(0);
}

void handle_sigchld(int sig) {
    (void)sig;
    int status;
    pid_t pid;
    while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
        for (int i = 0; i < job_count; i++) {
            if (job_list[i].pid == pid) {
                job_list[i].has_completed = 1;
                break;
            }
        }
    }
}

void load_stats_from_report() {
    FILE* report_file = fopen(REPORT_FILE, "r");
    if (!report_file) return;
    int pid, exec_slices, wait_slices;
    while (fscanf(report_file, "%d,%d,%d\n", &pid, &exec_slices, &wait_slices) == 3) {
        for (int i = 0; i < job_count; i++) {
            if (job_list[i].pid == pid) {
                job_list[i].time_sc_executed = exec_slices;
                job_list[i].time_sc_waited = wait_slices;
                break;
            }
        }
    }
    fclose(report_file);
}

void print_final_report() {
    printf("\n         Final Job Report         \n\n");
    printf("------------------------------------------------------------\n");
    printf(" %-20s  %-7s  %-15s  %-15s \n", "Command", "PID", "Execution Time", "Wait Time");
    printf("------------------------------------------------------------\n");
    for (int i = 0; i < job_count; i++) {
        char completion_time_str[32];
        char wait_time_str[32];
        int execution_time = (job_list[i].time_sc_executed > 0) ? job_list[i].time_sc_executed : 1;
        sprintf(completion_time_str, "%d x %dms", execution_time, tslice_val);
        sprintf(wait_time_str, "%d x %dms", job_list[i].time_sc_waited, tslice_val);
        printf(" %-20s  %-7d  %-15s  %-15s \n", job_list[i].name, job_list[i].pid, completion_time_str, wait_time_str);
    }
    printf("------------------------------------------------------------\n");
}

void cleanup_and_exit(int sig) {
    (void)sig;
    if (scheduler_pid > 0) {
        kill(scheduler_pid, SIGTERM);
        waitpid(scheduler_pid, NULL, 0);
    }
    load_stats_from_report();
    print_final_report();
    remove(JOBS_FILE);
    remove(REPORT_FILE);
    exit(0);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <NCPU> <TSLICE_ms>\n", argv[0]);
        return 1;
    }
    tslice_val = atoi(argv[2]);

    remove(JOBS_FILE);
    remove(REPORT_FILE);

    scheduler_pid = fork();
    if (scheduler_pid == 0) {
        char* scheduler_args[] = {"./scheduler", argv[1], argv[2], NULL};
        execvp(scheduler_args[0], scheduler_args);
        perror("execvp for scheduler failed");
        exit(1);
    } else if (scheduler_pid > 0) {
        signal(SIGINT, cleanup_and_exit);
        signal(SIGCHLD, handle_sigchld);
        shell_loop();
    } else {
        perror("fork failed");
        return 1;
    }
    return 0;
}